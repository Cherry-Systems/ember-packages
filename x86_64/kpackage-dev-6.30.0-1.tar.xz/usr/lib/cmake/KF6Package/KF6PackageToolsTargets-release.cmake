#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "KF6::kpackagetool6" for configuration "Release"
set_property(TARGET KF6::kpackagetool6 APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(KF6::kpackagetool6 PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/kpackagetool6"
  )

list(APPEND _cmake_import_check_targets KF6::kpackagetool6 )
list(APPEND _cmake_import_check_files_for_KF6::kpackagetool6 "${_IMPORT_PREFIX}/bin/kpackagetool6" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
