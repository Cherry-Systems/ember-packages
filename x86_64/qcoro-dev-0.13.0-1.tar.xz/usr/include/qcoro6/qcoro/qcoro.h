// SPDX-FileCopyrightText: 2021 Daniel Vrátil <dvratil@kde.org>
//
// SPDX-License-Identifier: MIT

#pragma once

#define QCORO_WITH_QTDBUS
#define QCORO_WITH_QTNETWORK

#include "task.h"
#include "qcorocore.h"

#if defined(QCORO_WITH_QTDBUS)
#include "qcorodbus.h"
#endif

#if defined(QCORO_WITH_QTNETWORK)
#include "qcoronetwork.h"
#endif
