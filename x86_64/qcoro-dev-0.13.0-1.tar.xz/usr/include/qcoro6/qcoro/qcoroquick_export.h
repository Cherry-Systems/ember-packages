
#ifndef QCOROQUICK_EXPORT_H
#define QCOROQUICK_EXPORT_H

#ifdef QCOROQUICK_STATIC_DEFINE
#  define QCOROQUICK_EXPORT
#  define QCOROQUICK_NO_EXPORT
#else
#  ifndef QCOROQUICK_EXPORT
#    ifdef QCoro6Quick_EXPORTS
        /* We are building this library */
#      define QCOROQUICK_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define QCOROQUICK_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef QCOROQUICK_NO_EXPORT
#    define QCOROQUICK_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef QCOROQUICK_DEPRECATED
#  define QCOROQUICK_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef QCOROQUICK_DEPRECATED_EXPORT
#  define QCOROQUICK_DEPRECATED_EXPORT QCOROQUICK_EXPORT QCOROQUICK_DEPRECATED
#endif

#ifndef QCOROQUICK_DEPRECATED_NO_EXPORT
#  define QCOROQUICK_DEPRECATED_NO_EXPORT QCOROQUICK_NO_EXPORT QCOROQUICK_DEPRECATED
#endif

/* NOLINTNEXTLINE(readability-avoid-unconditional-preprocessor-if) */
#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef QCOROQUICK_NO_DEPRECATED
#    define QCOROQUICK_NO_DEPRECATED
#  endif
#endif

#endif /* QCOROQUICK_EXPORT_H */
