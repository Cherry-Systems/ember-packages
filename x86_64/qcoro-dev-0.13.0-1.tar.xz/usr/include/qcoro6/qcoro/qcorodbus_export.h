
#ifndef QCORODBUS_EXPORT_H
#define QCORODBUS_EXPORT_H

#ifdef QCORODBUS_STATIC_DEFINE
#  define QCORODBUS_EXPORT
#  define QCORODBUS_NO_EXPORT
#else
#  ifndef QCORODBUS_EXPORT
#    ifdef QCoro6DBus_EXPORTS
        /* We are building this library */
#      define QCORODBUS_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define QCORODBUS_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef QCORODBUS_NO_EXPORT
#    define QCORODBUS_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef QCORODBUS_DEPRECATED
#  define QCORODBUS_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef QCORODBUS_DEPRECATED_EXPORT
#  define QCORODBUS_DEPRECATED_EXPORT QCORODBUS_EXPORT QCORODBUS_DEPRECATED
#endif

#ifndef QCORODBUS_DEPRECATED_NO_EXPORT
#  define QCORODBUS_DEPRECATED_NO_EXPORT QCORODBUS_NO_EXPORT QCORODBUS_DEPRECATED
#endif

/* NOLINTNEXTLINE(readability-avoid-unconditional-preprocessor-if) */
#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef QCORODBUS_NO_DEPRECATED
#    define QCORODBUS_NO_DEPRECATED
#  endif
#endif

#endif /* QCORODBUS_EXPORT_H */
