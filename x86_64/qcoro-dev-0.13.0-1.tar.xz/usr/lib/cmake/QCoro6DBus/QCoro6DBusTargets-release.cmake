#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "QCoro6::DBus" for configuration "Release"
set_property(TARGET QCoro6::DBus APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(QCoro6::DBus PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libQCoro6DBus.so.0.13.0"
  IMPORTED_SONAME_RELEASE "libQCoro6DBus.so.0"
  )

list(APPEND _cmake_import_check_targets QCoro6::DBus )
list(APPEND _cmake_import_check_files_for_QCoro6::DBus "${_IMPORT_PREFIX}/lib/libQCoro6DBus.so.0.13.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
