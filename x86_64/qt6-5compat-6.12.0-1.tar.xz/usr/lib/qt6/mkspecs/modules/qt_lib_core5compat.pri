QT.core5compat.VERSION = 6.12.0
QT.core5compat.name = QtCore5Compat
QT.core5compat.module = Qt6Core5Compat
QT.core5compat.libs = $$QT_MODULE_LIB_BASE
QT.core5compat.ldflags = 
QT.core5compat.includes = $$QT_MODULE_INCLUDE_BASE $$QT_MODULE_INCLUDE_BASE/QtCore5Compat
QT.core5compat.frameworks = 
QT.core5compat.bins = $$QT_MODULE_BIN_BASE
QT.core5compat.depends =  core
QT.core5compat.uses = 
QT.core5compat.module_config = v2
QT.core5compat.DEFINES = QT_CORE5COMPAT_LIB
QT.core5compat.enabled_features = iconv textcodec codecs big_codecs
QT.core5compat.disabled_features = 
QT_CONFIG += iconv textcodec codecs big_codecs
QT_MODULES += core5compat

