#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "KNightTime" for configuration "Release"
set_property(TARGET KNightTime APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(KNightTime PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "Qt6::DBus;KF6::Holidays"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libKNightTime.so.6.7.5"
  IMPORTED_SONAME_RELEASE "libKNightTime.so.0"
  )

list(APPEND _cmake_import_check_targets KNightTime )
list(APPEND _cmake_import_check_files_for_KNightTime "${_IMPORT_PREFIX}/lib/libKNightTime.so.6.7.5" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
