
#ifndef KNIGHTTIME_EXPORT_H
#define KNIGHTTIME_EXPORT_H

#ifdef KNIGHTTIME_STATIC_DEFINE
#  define KNIGHTTIME_EXPORT
#  define KNIGHTTIME_NO_EXPORT
#else
#  ifndef KNIGHTTIME_EXPORT
#    ifdef KNightTime_EXPORTS
        /* We are building this library */
#      define KNIGHTTIME_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KNIGHTTIME_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KNIGHTTIME_NO_EXPORT
#    define KNIGHTTIME_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KNIGHTTIME_DEPRECATED
#  define KNIGHTTIME_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KNIGHTTIME_DEPRECATED_EXPORT
#  define KNIGHTTIME_DEPRECATED_EXPORT KNIGHTTIME_EXPORT KNIGHTTIME_DEPRECATED
#endif

#ifndef KNIGHTTIME_DEPRECATED_NO_EXPORT
#  define KNIGHTTIME_DEPRECATED_NO_EXPORT KNIGHTTIME_NO_EXPORT KNIGHTTIME_DEPRECATED
#endif

/* NOLINTNEXTLINE(readability-avoid-unconditional-preprocessor-if) */
#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KNIGHTTIME_NO_DEPRECATED
#    define KNIGHTTIME_NO_DEPRECATED
#  endif
#endif

#endif /* KNIGHTTIME_EXPORT_H */
