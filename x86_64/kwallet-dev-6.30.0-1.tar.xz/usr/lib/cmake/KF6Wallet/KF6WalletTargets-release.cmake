#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "KF6::Wallet" for configuration "Release"
set_property(TARGET KF6::Wallet APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(KF6::Wallet PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "Qt6::DBus;KF6::ConfigGui"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libKF6Wallet.so.6.30.0"
  IMPORTED_SONAME_RELEASE "libKF6Wallet.so.6"
  )

list(APPEND _cmake_import_check_targets KF6::Wallet )
list(APPEND _cmake_import_check_files_for_KF6::Wallet "${_IMPORT_PREFIX}/lib/libKF6Wallet.so.6.30.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
