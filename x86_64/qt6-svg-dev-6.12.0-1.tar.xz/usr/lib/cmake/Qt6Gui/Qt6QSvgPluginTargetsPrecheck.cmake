
_qt_internal_should_include_targets(
    TARGETS QSvgPlugin
    NAMESPACE Qt6::
    PROJECT_NAMES QtSvg
    SKIP_IF_PROJECT_NAME_NOT_IN_QT_REPO_DEPENDENCIES
    OUT_VAR_SHOULD_SKIP __qt_QSvgPlugin_skip_include_targets_file
    
)
