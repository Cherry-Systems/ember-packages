
_qt_internal_should_include_targets(
    TARGETS Svg
    NAMESPACE Qt6::
    OUT_VAR_SHOULD_SKIP __qt_Svg_skip_include_targets_file
)
