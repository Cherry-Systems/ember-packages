#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Plasma::ActivitiesStats" for configuration "Release"
set_property(TARGET Plasma::ActivitiesStats APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Plasma::ActivitiesStats PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "Qt6::DBus;Qt6::Sql;Plasma::Activities;KF6::ConfigCore"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libPlasmaActivitiesStats.so.6.7.5"
  IMPORTED_SONAME_RELEASE "libPlasmaActivitiesStats.so.1"
  )

list(APPEND _cmake_import_check_targets Plasma::ActivitiesStats )
list(APPEND _cmake_import_check_files_for_Plasma::ActivitiesStats "${_IMPORT_PREFIX}/lib/libPlasmaActivitiesStats.so.6.7.5" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
