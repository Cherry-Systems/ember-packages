#define PCI_CONFIG_H
#define PCI_ARCH_X86_64
#define PCI_OS_LINUX
#define PCI_HAVE_PM_LINUX_SYSFS
#define PCI_HAVE_PM_LINUX_PROC
#define PCI_HAVE_PM_MMIO_CONF
#define PCI_HAVE_PM_ECAM
#define PCI_HAVE_LINUX_BYTEORDER_H
#define PCI_PATH_PROC_BUS_PCI "/proc/bus/pci"
#define PCI_PATH_SYS_BUS_PCI "/sys/bus/pci"
#define PCI_PATH_DEVMEM_DEVICE "/dev/mem"
#define PCI_PATH_ACPI_MCFG "/sys/firmware/acpi/tables/MCFG"
#define PCI_PATH_EFI_SYSTAB "/sys/firmware/efi/systab"
#define PCI_HAVE_PM_INTEL_CONF
#define PCI_HAVE_64BIT_ADDRESS
#define PCI_HAVE_PM_DUMP
#define PCI_IDS "pci.ids"
#define PCI_PATH_IDS_DIR "/usr/share/hwdata"
#define PCI_SHARED_LIB
#define PCILIB_VERSION "3.15.0"
#define PCILIB_DATE_AMIGAOS "05.04.2026"
