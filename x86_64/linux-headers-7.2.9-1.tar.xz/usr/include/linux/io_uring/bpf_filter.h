/* SPDX-License-Identifier: (GPL-2.0 WITH Linux-syscall-note) OR MIT */
/*
 * Header file for the io_uring BPF filters.
 */
#ifndef LINUX_IO_URING_BPF_FILTER_H
#define LINUX_IO_URING_BPF_FILTER_H

#include <linux/types.h>

/*
 * Struct passed to filters.
 */
struct io_uring_bpf_ctx {
	__u64	user_data;
	__u8	opcode;
	__u8	sqe_flags;
	__u8	pdu_size;	/* size of aux data for filter */
	__u8	pad[5];
	union {
		struct {
			__u32	family;
			__u32	type;
			__u32	protocol;
		} socket;
		struct {
			__u64	flags;
			__u64	mode;
			__u64	resolve;
		} open;
		/*
		 * For CONNECT: fields are populated only when addr_len covers
		 * them; unpopulated fields are zero from the caller-side memset
		 * in io_uring_populate_bpf_ctx(). port and v4_addr are network
		 * byte order. Filters may only issue BPF_LD|BPF_W|BPF_ABS at
		 * 4-byte aligned offsets; load + mask for sub-word fields.
		 */
		struct {
			__u32	family;	/* sa_family_t zero-extended */
			__be16	port;
			__u8	pad[2];
			union {
				__be32	v4_addr;
				__u8	v6_addr[16];
			};
		} connect;
	};
};

enum {
	/*
	 * If set, any currently unset opcode will have a deny filter attached
	 */
	IO_URING_BPF_FILTER_DENY_REST	= 1,
	/*
	 * If set, if kernel and application don't agree on pdu_size for
	 * the given opcode, fail the registration of the filter.
	 */
	IO_URING_BPF_FILTER_SZ_STRICT	= 2,
};

struct io_uring_bpf_filter {
	__u32	opcode;		/* io_uring opcode to filter */
	__u32	flags;
	__u32	filter_len;	/* number of BPF instructions */
	__u8	pdu_size;	/* expected pdu size for opcode */
	__u8	resv[3];
	__u64	filter_ptr;	/* pointer to BPF filter */
	__u64	resv2[5];
};

enum {
	IO_URING_BPF_CMD_FILTER	= 1,
};

struct io_uring_bpf {
	__u16	cmd_type;	/* IO_URING_BPF_* values */
	__u16	cmd_flags;	/* none so far */
	__u32	resv;
	union {
		struct io_uring_bpf_filter	filter;
	};
};

#endif
