import QtQuick
import calamares.slideshow 1.0

Presentation {
    id: presentation

    Timer {
        interval: 8000
        running: presentation.activatedInCalamares
        repeat: true
        onTriggered: presentation.goToNextSlide()
    }

    component EmberSlide: Slide {
        property alias heading: title.text
        property alias body: text.text

        Rectangle {
            anchors.fill: parent
            color: "#1c1917"
        }
        Image {
            id: logo
            source: "file:///usr/share/pixmaps/ember-logo.png"
            width: 128
            height: 128
            fillMode: Image.PreserveAspectFit
            anchors.horizontalCenter: parent.horizontalCenter
            anchors.top: parent.top
            anchors.topMargin: parent.height * 0.12
        }
        Text {
            id: title
            color: "#fafaf9"
            font.pixelSize: 26
            font.bold: true
            anchors.horizontalCenter: parent.horizontalCenter
            anchors.top: logo.bottom
            anchors.topMargin: 24
        }
        Text {
            id: text
            color: "#d6d3d1"
            font.pixelSize: 16
            wrapMode: Text.WordWrap
            horizontalAlignment: Text.AlignHCenter
            width: parent.width * 0.75
            anchors.horizontalCenter: parent.horizontalCenter
            anchors.top: title.bottom
            anchors.topMargin: 16
        }
    }

    EmberSlide {
        heading: "Welcome to Ember Linux"
        body: "A small, fast system built from scratch, with the KDE Plasma desktop."
    }
    EmberSlide {
        heading: "Thousands of apps from Flathub"
        body: "Open Discover to browse, install and update apps. Each one runs in its own sandbox."
    }
    EmberSlide {
        heading: "Command-line packages too"
        body: "ember-pkg installs Ember's own packages: try \"ember-pkg search\" in Konsole."
    }
    EmberSlide {
        heading: "Almost done"
        body: "When the copy finishes, restart the computer and remove the USB stick or disc."
    }

    function onActivate() { presentation.currentSlide = 0 }
    function onLeave() { }
}
