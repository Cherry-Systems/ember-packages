# SPDX-License-Identifier: Apache-2.0
# Copyright 2014-2016 The Meson development team

from __future__ import annotations

import os
import typing as T
import xml.etree.ElementTree as ET

from .vs2010backend import Vs2010Backend
from ..mesonlib import MesonException

if T.TYPE_CHECKING:
    from ..arglist import CompilerArgs
    from ..build import Build
    from ..compilers.compilers import Language


class Vs2017Backend(Vs2010Backend):

    name = 'vs2017'

    def __init__(self, build: T.Optional[Build]):
        super().__init__(build)
        self.vs_version = '2017'
        self.sln_file_version = '12.00'
        self.sln_version_comment = '15'

    def detect_toolset(self) -> None:
        # We assume that host == build
        if self.environment is not None:
            comps = self.environment.coredata.compilers.host
            if comps:
                if comps and all(c.id == 'clang-cl' for c in comps.values()):
                    self.platform_toolset = 'llvm'
                elif comps and all(c.id == 'intel-cl' for c in comps.values()):
                    c = list(comps.values())[0]
                    if c.version.startswith('19'):
                        self.platform_toolset = 'Intel C++ Compiler 19.0'
                    else:
                        # We don't have support for versions older than 2019 right now.
                        raise MesonException('There is currently no support for ICL before 19, patches welcome.')
        if self.platform_toolset is None:
            self.platform_toolset = 'v141'
        # WindowsSDKVersion should be set by command prompt.
        sdk_version = os.environ.get('WindowsSDKVersion', None)
        if sdk_version:
            self.windows_target_platform_version = sdk_version.rstrip('\\')

    def generate_debug_information(self, link: ET.Element) -> None:
        # valid values for vs2017 is 'false', 'true', 'DebugFastLink', 'DebugFull'
        ET.SubElement(link, 'GenerateDebugInformation').text = 'DebugFull'

    def generate_lang_standard_info(self, file_args: T.Dict[Language, CompilerArgs], clconf: ET.Element) -> None:
        if 'cpp' in file_args:
            optargs = [x for x in file_args['cpp'] if x.startswith('/std:c++')]
            if optargs:
                ET.SubElement(clconf, 'LanguageStandard').text = optargs[0].replace("/std:c++", "stdcpp")
        if 'c' in file_args:
            optargs = [x for x in file_args['c'] if x.startswith('/std:c')]
            if optargs:
                ET.SubElement(clconf, 'LanguageStandard_C').text = optargs[0].replace("/std:c", "stdc")
