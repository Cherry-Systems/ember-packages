#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Plasma::Plasma5Support" for configuration "Release"
set_property(TARGET Plasma::Plasma5Support APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Plasma::Plasma5Support PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "Qt6::Gui;Qt6::Sql;Qt6::Widgets;KF6::I18n;KF6::ConfigGui"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libPlasma5Support.so.6.7.5"
  IMPORTED_SONAME_RELEASE "libPlasma5Support.so.6"
  )

list(APPEND _cmake_import_check_targets Plasma::Plasma5Support )
list(APPEND _cmake_import_check_files_for_Plasma::Plasma5Support "${_IMPORT_PREFIX}/lib/libPlasma5Support.so.6.7.5" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
