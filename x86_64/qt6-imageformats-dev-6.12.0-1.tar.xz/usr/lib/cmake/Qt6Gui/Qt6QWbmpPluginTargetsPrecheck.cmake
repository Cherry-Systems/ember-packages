
_qt_internal_should_include_targets(
    TARGETS QWbmpPlugin
    NAMESPACE Qt6::
    PROJECT_NAMES QtImageFormats
    SKIP_IF_PROJECT_NAME_NOT_IN_QT_REPO_DEPENDENCIES
    OUT_VAR_SHOULD_SKIP __qt_QWbmpPlugin_skip_include_targets_file
    
)
