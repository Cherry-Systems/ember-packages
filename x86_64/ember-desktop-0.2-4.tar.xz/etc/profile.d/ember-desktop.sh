# Without NetworkManager, GLib's default network monitor reports "offline" for a
# moment at startup, and Discover only checks once when it opens.
export GIO_USE_NETWORK_MONITOR=netlink
