-- WirePlumber
--
-- Copyright © 2023 Collabora Ltd.
--    @author Ashok Sidipotu <ashok.sidipotu@collabora.com>
--
-- SPDX-License-Identifier: MIT

cutils = require ("common-utils")
mutils = require ("monitor-utils")

log = Log.open_topic ("s-monitors-v4l2")

config = {}
config.rules = Conf.get_section_as_json ("monitor.v4l2.rules", Json.Array {})

AsyncEventHook {
  name = "monitor/v4l2/create-node",
  after = "monitor/v4l2/name-node",
  interests = {
    EventInterest {
      Constraint { "event.type", "=", "create-v4l2-device-node" },
    },
  },
  steps = {
    start = {
      next = "none",
      execute = function (event, transition)
        local properties = event:get_data ("node-properties")
        local parent = event:get_subject ()
        local id = event:get_data ("node-sub-id")
        local factory = event:get_data ("factory")

        -- apply properties from rules defined in JSON .conf file
        properties = JsonUtils.match_rules_update_properties (config.rules, properties)

        if cutils.parseBool (properties ["node.disabled"]) then
          log:notice ("V4L2 node " .. properties ["node.name"] .. " disabled")
          transition:advance ()
          return
        end

        -- create the node
        local node = Node ("spa-node-factory", properties)
        if node == nil then
          transition:return_error ("Failed to create V4L2 node " ..
              tostring (properties ["node.name"]))
          return
        end

        node:activate (Features.ALL, function (n, e)
          if e ~= nil then
            transition:return_error ("Failed to activate V4L2 node " ..
                tostring (properties ["node.name"]) .. ": " .. e)
            return
          end

          parent:store_managed_object (id, node)
          transition:advance ()
        end)
      end
    },
  }
}:register ()
