if [ -n "$BASH_VERSION" ] && [ -z "$POSIXLY_CORRECT" ] && [ -r /usr/share/bash-completion/bash_completion ]; then
. /usr/share/bash-completion/bash_completion
fi
