#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "KF6::UserFeedbackCore" for configuration "Release"
set_property(TARGET KF6::UserFeedbackCore APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(KF6::UserFeedbackCore PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "Qt6::Gui;Qt6::Network"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libKF6UserFeedbackCore.so.6.30.0"
  IMPORTED_SONAME_RELEASE "libKF6UserFeedbackCore.so.6"
  )

list(APPEND _cmake_import_check_targets KF6::UserFeedbackCore )
list(APPEND _cmake_import_check_files_for_KF6::UserFeedbackCore "${_IMPORT_PREFIX}/lib/libKF6UserFeedbackCore.so.6.30.0" )

# Import target "KF6::UserFeedbackWidgets" for configuration "Release"
set_property(TARGET KF6::UserFeedbackWidgets APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(KF6::UserFeedbackWidgets PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libKF6UserFeedbackWidgets.so.6.30.0"
  IMPORTED_SONAME_RELEASE "libKF6UserFeedbackWidgets.so.6"
  )

list(APPEND _cmake_import_check_targets KF6::UserFeedbackWidgets )
list(APPEND _cmake_import_check_files_for_KF6::UserFeedbackWidgets "${_IMPORT_PREFIX}/lib/libKF6UserFeedbackWidgets.so.6.30.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
