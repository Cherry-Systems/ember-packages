// SPDX-FileCopyrightText: 2018 Aleix Pol Gonzalez <aleixpol@blue-systems.com>
// SPDX-FileCopyrightText: 2021 Carl Schwan <carl@carlschwan.eu>
// SPDX-License-Identifier: LGPL-2.0-or-later

import QtQuick
import QtQuick.Controls as QQC2
import QtQuick.Window
import QtQuick.Layouts
import org.kde.kirigami as Kirigami
import org.kde.kirigamiaddons.components as KirigamiComponents
import org.kde.kirigamiaddons.formcard as FormCardModule
import org.kde.coreaddons as Core

import "private" as Private

/*!
   \qmltype AboutPage
   \inqmlmodule org.kde.kirigamiaddons.formcard
   \brief An AboutPage that displays the about data using Form components.

   This component consists of an internationalized "About" page with the
   metadata of your program.

   It allows to show the copyright notice of the application together with
   the contributors and some information of which platform it's running on.

   \since 0.11.0
 */
FormCardPage {
    id: page

    /*!
       \brief This property holds an object with the same shape as KAboutData.

       Set this property to either a KAboutData instance exposed from C++, or directly via a JSON object.

       Example usage:
       \code{json}
       aboutData: {
          "displayName" : "KirigamiApp",
          "productName" : "kirigami/app",
          "componentName" : "kirigamiapp",
          "shortDescription" : "A Kirigami example",
          "homepage" : "",
          "bugAddress" : "submit@bugs.kde.org",
          "version" : "5.14.80",
          "otherText" : "",
          "authors" : [
              {
                  "name" : "...",
                  "task" : "...",
                  "emailAddress" : "somebody@kde.org",
                  "webAddress" : "",
                  "ocsUsername" : ""
              }
          ],
          "credits" : [],
          "translators" : [],
          "licenses" : [
              {
                  "name" : "GPL v2",
                  "text" : "long, boring, license text",
                  "spdx" : "GPL-2.0"
              }
          ],
          "releases" : [
              {
                  "version" : "1.0.0",
                  "date" : "2025-01-01",
                  "description" : "Initial release.",
                  "url" : "https://example.org/releases/1.0.0"
              }
          ],
          "copyrightStatement" : "© 2010-2018 Plasma Development Team",
          "desktopFileName" : "org.kde.kirigamiapp"
       }
       \endcode

       \sa KAboutData
     */
    property var aboutData: Core.AboutData

    /*!
       \brief This property holds a link to a "Get Involved" page.

       Default: "https://community.kde.org/Get_Involved" when the
       application ID starts with "org.kde.", otherwise empty.
     */
    property url getInvolvedUrl: {
        if (aboutData.hasOwnProperty("url") && aboutData.url(Core.AboutUrlType?.Contribute) !== "")
            return aboutData.url(Core.AboutUrlType?.Contribute);
        return aboutData.desktopFileName.startsWith("org.kde.") ? "https://community.kde.org/Get_Involved" : "";
    }

    /*!
       \brief This property holds a link to a "Donate" page.

       Default: "https://www.kde.org/donate" when the
       application ID starts with "org.kde.", otherwise empty.
     */
    property url donateUrl: {
        if (page.aboutData.hasOwnProperty("url") && aboutData.url(Core.AboutUrlType?.Donation) !== "")
            return aboutData.url(Core.AboutUrlType?.Donation);
        return aboutData.desktopFileName.startsWith("org.kde.") ? "https://www.kde.org/donate" : ""
    }

    /*!
       \brief This property defines whether to show "Libraries in use".

       Default: true
     */
    property bool showLibraries: true

    property bool _showOnlyNewReleases: false

    Binding {
        target: FormCardModule.AboutComponent
        property: "currentVersion"
        value: page.aboutData.version
    }

    Binding {
        target: FormCardModule.AboutComponent
        property: "releaseVersions"
        value: page.aboutData.releases ? page.aboutData.releases.map(release => release.version) : []
    }

    title: i18nd("kirigami-addons6", "About %1", page.aboutData.displayName)

    FormCard {
        Layout.topMargin: Kirigami.Units.largeSpacing * 4

        AbstractFormDelegate {
            id: generalDelegate
            Layout.fillWidth: true
            background: FormDelegateBackground {
                control: generalDelegate
                visible: page.aboutData.releases && page.aboutData.releases.length > 0
            }
            contentItem: RowLayout {
                spacing: Kirigami.Units.smallSpacing * 2

                Kirigami.Icon {
                    Layout.preferredHeight: Kirigami.Units.iconSizes.huge
                    Layout.preferredWidth: height
                    Layout.maximumWidth: page.width / 3;
                    Layout.rightMargin: Kirigami.Units.largeSpacing
                    source: page.aboutData.programLogo || Kirigami.Settings.applicationWindowIcon || page.aboutData.componentName
                }

                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: Kirigami.Units.smallSpacing

                    RowLayout {
                        spacing: Kirigami.Units.smallSpacing

                        Kirigami.Heading {
                            Layout.fillWidth: true
                            text: page.aboutData.displayName + " " + page.aboutData.version
                            wrapMode: Text.WordWrap
                        }

                        Kirigami.Badge {
                            visible: FormCardModule.AboutComponent.hasNewReleases
                            text: i18nd("kirigami-addons6", "What's new")
                            type: Kirigami.Badge.Type.Positive
                        }
                    }


                    Kirigami.Heading {
                        Layout.fillWidth: true
                        level: 3
                        type: Kirigami.Heading.Type.Secondary
                        wrapMode: Text.WordWrap
                        text: page.aboutData.shortDescription
                    }
                }
            }

            onClicked: {
                if (page.aboutData.releases && page.aboutData.releases.length > 0) {
                    page._showOnlyNewReleases = FormCardModule.AboutComponent.hasNewReleases;
                    releasesSheet.open();
                    FormCardModule.AboutComponent.updateLastSeenVersion();
                }
            }
        }

        FormDelegateSeparator {}

        FormTextDelegate {
            id: copyrightDelegate
            visible: aboutData.copyrightStatement.length > 0
            text: i18nd("kirigami-addons6", "Copyright")
            descriptionItem.textFormat: Text.PlainText
            description: aboutData.copyrightStatement
        }

        data: QQC2.Dialog {
            id: releasesSheet

            title: i18nd("kirigami-addons6", "Release history")
            parent: QQC2.Overlay.overlay
            x: Math.round((parent.width - width) / 2)
            y: Math.round((parent.height - height) / 2)
            implicitWidth: parent ? Math.min(parent.width - Kirigami.Units.gridUnit * 2, Kirigami.Units.gridUnit * 30) : Kirigami.Units.gridUnit * 30
            implicitHeight: Math.min(parent ? parent.height - Kirigami.Units.gridUnit * 2 : Kirigami.Units.gridUnit * 32,
                                     Kirigami.Units.gridUnit * 32,
                                     releaseDialogHeader.implicitHeight + releasesColumn.implicitHeight + Kirigami.Units.gridUnit * 2)
            modal: true
            focus: true
            background: KirigamiComponents.DialogRoundedBackground {}

            leftPadding: 0
            rightPadding: 0
            bottomPadding: 0
            topPadding: 0

            header: QQC2.Control {
                id: releaseDialogHeader
                padding: releasesSheet.padding
                topPadding: Kirigami.Units.largeSpacing
                bottomPadding: Kirigami.Units.largeSpacing

                contentItem: RowLayout {
                    spacing: Kirigami.Units.largeSpacing

                    Kirigami.Heading {
                        text: releasesSheet.title
                        elide: QQC2.Label.ElideRight
                        padding: 0
                        leftPadding: Kirigami.Units.largeSpacing
                        Layout.fillWidth: true
                    }

                    QQC2.ToolButton {
                        icon.name: hovered ? "window-close" : "window-close-symbolic"
                        text: i18ndc("kirigami-addons6", "@action:button", "Close")
                        display: QQC2.ToolButton.IconOnly
                        onClicked: releasesSheet.close()
                    }
                }

                Kirigami.Separator {
                    anchors {
                        left: parent.left
                        right: parent.right
                        bottom: parent.bottom
                    }
                }
            }

            contentItem: QQC2.ScrollView {
                id: releasesScrollView
                contentWidth: availableWidth
                contentHeight: releasesColumn.implicitHeight + Kirigami.Units.gridUnit * 2
                QQC2.ScrollBar.horizontal.policy: QQC2.ScrollBar.AlwaysOff

                ColumnLayout {
                    id: releasesColumn
                    x: Kirigami.Units.gridUnit
                    y: Kirigami.Units.gridUnit
                    width: releasesScrollView.availableWidth - Kirigami.Units.gridUnit * 2
                    spacing: Kirigami.Units.largeSpacing * 2

                    Repeater {
                        model: page._showOnlyNewReleases
                            ? page.aboutData.releases.filter((release, index) => FormCardModule.AboutComponent.newReleaseIndexes.includes(index))
                            : page.aboutData.releases
                        delegate: releaseDelegate
                    }

                    QQC2.Button {
                        Layout.alignment: Qt.AlignHCenter
                        visible: page._showOnlyNewReleases
                        text: i18nd("kirigami-addons6", "Show older changes…")
                        onClicked: page._showOnlyNewReleases = false
                    }
                }
            }

            footer: null
        }
    }

    FormHeader {
        visible: aboutData.otherText.length > 0
        title: i18nd("kirigami-addons6", "Description")
    }

    FormCard {
        visible: aboutData.otherText.length > 0
        FormTextDelegate {
            Layout.fillWidth: true
            textItem.wrapMode: Text.WordWrap
            text: aboutData.otherText
        }
    }

    FormHeader {
        title: i18ndp("kirigami-addons6", "License", "Licenses", aboutData.licenses.length)
        visible: aboutData.licenses.length
    }

    FormCard {
        visible: aboutData.licenses.length

        Repeater {
            model: aboutData.licenses
            delegate: FormButtonDelegate {
                text: modelData.name
                Layout.fillWidth: true
                onClicked: {
                    licenseSheet.text = modelData.text;
                    licenseSheet.title = modelData.name;
                    licenseSheet.open();
                }
            }
        }

        data: KirigamiComponents.MessageDialog {
            id: licenseSheet

            property alias text: bodyLabel.text

            parent: QQC2.Overlay.overlay
            implicitWidth: parent ? Math.min(parent.width - Kirigami.Units.gridUnit * 2, Kirigami.Units.gridUnit * 30) : Kirigami.Units.gridUnit * 30

            leftPadding: 0
            rightPadding: 0
            bottomPadding: 0
            topPadding: 0

            header: QQC2.Control {
                padding: licenseSheet.padding
                topPadding: Kirigami.Units.largeSpacing
                bottomPadding: Kirigami.Units.largeSpacing

                contentItem: RowLayout {
                    spacing: Kirigami.Units.largeSpacing

                    Kirigami.Heading {
                        text: licenseSheet.title
                        elide: QQC2.Label.ElideRight
                        padding: 0
                        leftPadding: Kirigami.Units.largeSpacing
                        Layout.fillWidth: true
                    }

                    QQC2.ToolButton {
                        icon.name: hovered ? "window-close" : "window-close-symbolic"
                        text: i18ndc("kirigami-addons6", "@action:button", "Close")
                        display: QQC2.ToolButton.IconOnly
                        onClicked: licenseSheet.close()
                    }
                }

                Kirigami.Separator {
                    anchors {
                        left: parent.left
                        right: parent.right
                        bottom: parent.bottom
                    }
                }
            }

            contentItem: QQC2.ScrollView {
                id: scrollView
                contentWidth: availableWidth
                QQC2.ScrollBar.horizontal.policy: QQC2.ScrollBar.AlwaysOff

                Kirigami.SelectableLabel {
                    id: bodyLabel
                    width: scrollView.availableWidth
                    text: licenseSheet.text
                    textMargin: Kirigami.Units.gridUnit
                    wrapMode: Text.WordWrap
                }
            }

            footer: null
        }
    }

    FormGridContainer {
        Layout.topMargin: Kirigami.Units.gridUnit
        Layout.fillWidth: true

        // hide the container if all contents are not visible
        visible: getInvolvedDelegate.visible
              || donateDelegate.visible
              || homepageDelegate.visible
              || bugDelegate.visible
              || matrixRoomDelegate.visible
              || mastodonDelegate.visible
              || sourceCodeDelegate.visible

        FormLinkDelegate {
            id: getInvolvedDelegate
            icon.name: "globe-symbolic"
            text: i18nd("kirigami-addons6", "Homepage")
            url: aboutData.homepage
            visible: aboutData.homepage.length > 0
        }

        FormLinkDelegate {
            id: donateDelegate
            icon.name: "donate-symbolic"
            text: i18nd("kirigami-addons6", "Donate")
            url: donateUrl + "?app=" + page.aboutData.componentName
            visible: donateUrl.toString().length > 0
        }

        FormLinkDelegate {
            id: homepageDelegate
            icon.name: "applications-development-symbolic"
            text: i18nd("kirigami-addons6", "Get Involved")
            url: page.getInvolvedUrl
            visible: page.getInvolvedUrl != ""
        }

        FormLinkDelegate {
            id: bugDelegate
            url: {
                if (aboutData.bugAddress !== "submit@bugs.kde.org") {
                    return aboutData.bugAddress
                }
                const elements = aboutData.productName.split('/');
                let url = `https://bugs.kde.org/enter_bug.cgi?format=guided&product=${elements[0]}&version=${aboutData.version}`;
                if (elements.length === 2) {
                    url += "&component=" + elements[1];
                }
                return url;
            }

            icon.name: "tools-report-bug-symbolic"
            text: i18nd("kirigami-addons6", "Report a Bug")
            visible: url.length > 0
        }

        FormLinkDelegate {
            id: matrixRoomDelegate
            url: {
                if (!page.aboutData.hasOwnProperty("url")) // since KF 6.29
                    return "";
                const s = page.aboutData.url(Core.AboutUrlType?.XKDEMatrixRoom);
                return s.startsWith("http") ? s : s != "" ? "https://matrix.to/#/" + s : "";
            }
            icon.name: "im-matrix"
            text: i18nd("kirigami-addons6", "Matrix Channel")
            visible: url.length > 0
        }

        FormLinkDelegate {
            id: mastodonDelegate
            url: {
                if (!page.aboutData.hasOwnProperty("url")) // since KF 6.29
                    return "";
                const s = page.aboutData.url(Core.AboutUrlType?.XKDEMastodon);
                if (s == "" || s.startsWith("http"))
                    return s;
                const m = s.match(/^(@\S*)@(\S+)$/);
                return m ? ("https://" + m[2] + "/" + m[1]) : ""
            }
            icon.name: "im-mastodon"
            text: i18nd("kirigami-addons6", "Mastodon")
            visible: url.length > 0
        }

        FormLinkDelegate {
            id: sourceCodeDelegate
            url: {
                if (!page.aboutData.hasOwnProperty("url")) // since KF 6.29
                    return "";
                page.aboutData.url(Core.AboutUrlType?.VCSBrowser)
            }
            icon.name: "code-context-symbolic"
            text: i18nd("kirigami-addons6", "Source Code")
            visible: url.length > 0
        }
    }

    FormHeader {
        title: i18nd("kirigami-addons6", "Libraries in use")
        visible: page.showLibraries

        actions: QQC2.Action {
            text: i18ndc("kirigami-addons6", "@action:button", "Copy to Clipboard")
            icon.name: 'edit-copy-symbolic'
            onTriggered: {
                FormCardModule.AboutComponent.copyToClipboard();
                page.QQC2.ApplicationWindow.window.showPassiveNotification(i18ndc("kirigami-addons6", "@info", "System information copied to clipboard."), 'short');
            }
        }
    }

    FormCard {
        visible: page.showLibraries
        autoSeparators: true
        Repeater {
            model: page.showLibraries ? FormCardModule.AboutComponent.components : null
            delegate: libraryDelegate
        }
    }

    FormHeader {
        title: i18nd("kirigami-addons6", "Authors")
        visible: aboutData.authors !== undefined && aboutData.authors.length > 0
    }

    FormCard {
        visible: aboutData.authors !== undefined && aboutData.authors.length > 0
        autoSeparators: true

        Repeater {
            id: authorsRepeater
            model: aboutData.authors
            delegate: personDelegate
        }
    }

    FormHeader {
        title: i18nd("kirigami-addons6", "Credits")
        visible: aboutData.credits !== undefined && aboutData.credits.length > 0
    }

    FormCard {
        visible: aboutData.credits !== undefined && aboutData.credits.length > 0
        autoSeparators: true

        Repeater {
            id: repCredits
            model: aboutData.credits
            delegate: personDelegate
        }
    }

    FormHeader {
        title: i18nd("kirigami-addons6", "Translators")
        visible: aboutData.translators !== undefined && aboutData.translators.length > 0
    }

    FormCard {
        visible: aboutData.translators !== undefined && aboutData.translators.length > 0
        autoSeparators: true

        Repeater {
            id: repTranslators
            model: aboutData.translators
            delegate: personDelegate
        }
    }

    data: [
        Component {
            id: releaseDelegate

            ColumnLayout {
                required property var modelData

                Layout.fillWidth: true
                Layout.preferredWidth: Kirigami.Units.gridUnit * 30
                spacing: Kirigami.Units.smallSpacing

                QQC2.Label {
                    Layout.fillWidth: true
                    text: modelData.version
                    font.bold: true
                }

                QQC2.Label {
                    Layout.fillWidth: true
                    text: modelData.date.toLocaleDateString()
                    color: Kirigami.Theme.disabledTextColor
                    visible: modelData.date && modelData.date.getTime() !== 0
                }

                QQC2.Label {
                    Layout.fillWidth: true
                    Layout.minimumWidth: 0
                    text: modelData.description
                    textFormat: Text.RichText
                    wrapMode: Text.WordWrap
                    onLinkActivated: (link) => Qt.openUrlExternally(link)
                    visible: text.length > 0
                }

                FormLinkDelegate {
                    Layout.fillWidth: true
                    text: i18nd("kirigami-addons6", "More information")
                    url: modelData.url
                    visible: url.toString().length > 0
                }
            }
        },
        Component {
            id: personDelegate

            AbstractFormDelegate {
                Layout.fillWidth: true
                background: null
                contentItem: RowLayout {
                    spacing: Private.FormCardUnits.horizontalSpacing

                    KirigamiComponents.Avatar {
                        id: avatarIcon

                        implicitWidth: Kirigami.Units.iconSizes.medium
                        implicitHeight: implicitWidth
                        name: modelData.name
                        source: if (!!modelData.avatarUrl && modelData.avatarUrl.toString().startsWith('https://')) {
                            const url = new URL(modelData.avatarUrl);
                            const params = new URLSearchParams(url.search);
                            params.append("s", width);
                            url.search = params.toString();
                            return url;
                        } else {
                            return '';
                        }

                        Layout.rightMargin: Private.FormCardUnits.horizontalSpacing
                    }

                    ColumnLayout {
                        Layout.fillWidth: true
                        spacing: Private.FormCardUnits.verticalSpacing

                        QQC2.Label {
                            Layout.fillWidth: true
                            text: modelData.name
                            elide: Text.ElideRight
                        }

                        QQC2.Label {
                            id: internalDescriptionItem
                            Layout.fillWidth: true
                            text: modelData.task
                            color: Kirigami.Theme.disabledTextColor
                            font: Kirigami.Theme.smallFont
                            elide: Text.ElideRight
                            visible: text.length > 0
                        }
                    }

                    QQC2.ToolButton {
                        visible: typeof(modelData.ocsUsername) !== "undefined" && modelData.ocsUsername.length > 0
                        icon.name: "get-hot-new-stuff-symbolic"
                        QQC2.ToolTip.delay: Kirigami.Units.toolTipDelay
                        QQC2.ToolTip.visible: hovered
                        QQC2.ToolTip.text: i18nd("kirigami-addons6", "Visit %1's KDE Store page", modelData.name)
                        onClicked: Qt.openUrlExternally("https://store.kde.org/u/%1".arg(modelData.ocsUsername))
                    }

                    QQC2.ToolButton {
                        visible: typeof(modelData.emailAddress) !== "undefined" && modelData.emailAddress.length > 0
                        icon.name: "mail-sent-symbolic"
                        QQC2.ToolTip.delay: Kirigami.Units.toolTipDelay
                        QQC2.ToolTip.visible: hovered
                        QQC2.ToolTip.text: i18nd("kirigami-addons6", "Send an email to %1", modelData.emailAddress)
                        onClicked: Qt.openUrlExternally("mailto:%1".arg(modelData.emailAddress))
                    }

                    QQC2.ToolButton {
                        visible: typeof(modelData.webAddress) !== "undefined" && modelData.webAddress.length > 0
                        icon.name: "globe-symbolic"
                        QQC2.ToolTip.delay: Kirigami.Units.toolTipDelay
                        QQC2.ToolTip.visible: hovered
                        QQC2.ToolTip.text: (typeof(modelData.webAddress) === "undefined" && modelData.webAddress.length > 0) ? "" : modelData.webAddress
                        onClicked: Qt.openUrlExternally(modelData.webAddress)
                    }
                }
            }
        },
        Component {
            id: libraryDelegate

            AbstractFormDelegate {
                id: delegate

                required property var modelData

                Layout.fillWidth: true
                background: null
                contentItem: RowLayout {
                    spacing: Private.FormCardUnits.horizontalSpacing

                    ColumnLayout {
                        Layout.fillWidth: true
                        spacing: Private.FormCardUnits.verticalSpacing

                        QQC2.Label {
                            Layout.fillWidth: true
                            text: delegate.modelData.name + ' ' + delegate.modelData.version
                            wrapMode: Text.WordWrap
                        }

                        QQC2.Label {
                            id: internalDescriptionItem
                            Layout.fillWidth: true
                            text: delegate.modelData.description
                            color: Kirigami.Theme.disabledTextColor
                            font: Kirigami.Theme.smallFont
                            wrapMode: Text.WordWrap
                            visible: text.length > 0
                        }
                    }

                    QQC2.ToolButton {
                        id: licenseButton
                        visible: modelData.licenses.key !== 0
                        icon.name: "license-symbolic"

                        QQC2.ToolTip.delay: Kirigami.Units.toolTipDelay
                        QQC2.ToolTip.visible: hovered
                        QQC2.ToolTip.text: !visible ? "" : delegate.modelData.licenses.name

                        KirigamiComponents.MessageDialog {
                            id: licenseSheet

                            title: delegate.modelData.name

                            parent: licenseButton.QQC2.Overlay.overlay
                            implicitWidth: parent ? Math.min(parent.width - Kirigami.Units.gridUnit * 2, implicitContentWidth) : implicitContentWidth

                            leftPadding: 0
                            rightPadding: 0
                            bottomPadding: 0
                            topPadding: 0

                            header: QQC2.Control {
                                padding: licenseSheet.padding
                                topPadding: Kirigami.Units.largeSpacing
                                bottomPadding: Kirigami.Units.largeSpacing

                                contentItem: RowLayout {
                                    spacing: Kirigami.Units.largeSpacing

                                    Kirigami.Heading {
                                        text: licenseSheet.title
                                        elide: QQC2.Label.ElideRight
                                        padding: 0
                                        leftPadding: Kirigami.Units.largeSpacing
                                        Layout.fillWidth: true
                                    }

                                    QQC2.ToolButton {
                                        icon.name: hovered ? "window-close" : "window-close-symbolic"
                                        text: i18ndc("kirigami-addons6", "@action:button", "Close")
                                        display: QQC2.ToolButton.IconOnly
                                        onClicked: licenseSheet.close()
                                    }
                                }

                                Kirigami.Separator {
                                    anchors {
                                        left: parent.left
                                        right: parent.right
                                        bottom: parent.bottom
                                    }
                                }
                            }

                            contentItem: QQC2.ScrollView {
                                Kirigami.SelectableLabel {
                                    id: bodyLabel
                                    text: delegate.modelData.licenses.text
                                    textMargin: Kirigami.Units.gridUnit
                                    wrapMode: Text.WordWrap
                                    onLinkActivated: (link) => { Qt.openUrlExternally(link); }
                                }
                            }

                            footer: null
                        }

                        onClicked: licenseSheet.open()
                    }

                    QQC2.ToolButton {
                        visible: typeof(modelData.webAddress) !== "undefined" && modelData.webAddress.length > 0
                        icon.name: "globe-symbolic"
                        QQC2.ToolTip.delay: Kirigami.Units.toolTipDelay
                        QQC2.ToolTip.visible: hovered
                        QQC2.ToolTip.text: (typeof(modelData.webAddress) === "undefined" && modelData.webAddress.length > 0) ? "" : modelData.webAddress
                        onClicked: Qt.openUrlExternally(modelData.webAddress)
                    }
                }
            }
        }
    ]
}
