#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Plasma::KWaylandClient" for configuration "Release"
set_property(TARGET Plasma::KWaylandClient APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Plasma::KWaylandClient PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "Qt6::Concurrent"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libKWaylandClient.so.6.7.5"
  IMPORTED_SONAME_RELEASE "libKWaylandClient.so.6"
  )

list(APPEND _cmake_import_check_targets Plasma::KWaylandClient )
list(APPEND _cmake_import_check_files_for_Plasma::KWaylandClient "${_IMPORT_PREFIX}/lib/libKWaylandClient.so.6.7.5" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
