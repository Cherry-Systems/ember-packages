QT.qmldesignsupport.VERSION = 6.12.0
QT.qmldesignsupport.name = QtQmlDesignSupport
QT.qmldesignsupport.module = Qt6QmlDesignSupport
QT.qmldesignsupport.libs = $$QT_MODULE_LIB_BASE
QT.qmldesignsupport.ldflags = 
QT.qmldesignsupport.includes = $$QT_MODULE_INCLUDE_BASE $$QT_MODULE_INCLUDE_BASE/QtQmlDesignSupport
QT.qmldesignsupport.frameworks = 
QT.qmldesignsupport.bins = $$QT_MODULE_BIN_BASE
QT.qmldesignsupport.depends =  core qml
QT.qmldesignsupport.uses = 
QT.qmldesignsupport.module_config = v2
QT.qmldesignsupport.DEFINES = QT_QMLDESIGNSUPPORT_LIB
QT.qmldesignsupport.enabled_features = 
QT.qmldesignsupport.disabled_features = 
QT_CONFIG += 
QT_MODULES += qmldesignsupport

