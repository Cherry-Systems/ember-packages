QT.quickcontrols2fluentwinui3.VERSION = 6.12.0
QT.quickcontrols2fluentwinui3.name = QtQuickControls2FluentWinUI3
QT.quickcontrols2fluentwinui3.module = Qt6QuickControls2FluentWinUI3
QT.quickcontrols2fluentwinui3.libs = $$QT_MODULE_LIB_BASE
QT.quickcontrols2fluentwinui3.ldflags = 
QT.quickcontrols2fluentwinui3.includes = $$QT_MODULE_INCLUDE_BASE $$QT_MODULE_INCLUDE_BASE/QtQuickControls2FluentWinUI3
QT.quickcontrols2fluentwinui3.frameworks = 
QT.quickcontrols2fluentwinui3.bins = $$QT_MODULE_BIN_BASE
QT.quickcontrols2fluentwinui3.depends =  
QT.quickcontrols2fluentwinui3.run_depends = core gui qml quickcontrols2fluentwinui3styleimpl quickcontrols2impl quicktemplates2 quickcontrols2fusion
QT.quickcontrols2fluentwinui3.uses = 
QT.quickcontrols2fluentwinui3.module_config = v2
QT.quickcontrols2fluentwinui3.DEFINES = QT_QUICKCONTROLS2FLUENTWINUI3_LIB
QT.quickcontrols2fluentwinui3.enabled_features = 
QT.quickcontrols2fluentwinui3.disabled_features = 
QT_CONFIG += 
QT_MODULES += quickcontrols2fluentwinui3

