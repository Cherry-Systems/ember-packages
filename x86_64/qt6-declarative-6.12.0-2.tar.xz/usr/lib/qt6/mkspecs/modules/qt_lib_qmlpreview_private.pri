QT.qmlpreview_private.VERSION = 6.12.0
QT.qmlpreview_private.name = QtQmlPreview
QT.qmlpreview_private.module = Qt6QmlPreview
QT.qmlpreview_private.libs = $$QT_MODULE_LIB_BASE
QT.qmlpreview_private.ldflags = 
QT.qmlpreview_private.includes = $$QT_MODULE_INCLUDE_BASE $$QT_MODULE_INCLUDE_BASE/QtQmlPreview $$QT_MODULE_INCLUDE_BASE/QtQmlPreview/6.12.0 $$QT_MODULE_INCLUDE_BASE/QtQmlPreview/6.12.0/QtQmlPreview
QT.qmlpreview_private.frameworks = 
QT.qmlpreview_private.bins = $$QT_MODULE_BIN_BASE
QT.qmlpreview_private.depends =  core qml_private
QT.qmlpreview_private.uses = 
QT.qmlpreview_private.module_config = v2 internal_module staticlib
QT.qmlpreview_private.DEFINES = QT_QMLPREVIEW_LIB
QT.qmlpreview_private.enabled_features = 
QT.qmlpreview_private.disabled_features = 
QT_CONFIG += 
QT_MODULES += qmlpreview_private

