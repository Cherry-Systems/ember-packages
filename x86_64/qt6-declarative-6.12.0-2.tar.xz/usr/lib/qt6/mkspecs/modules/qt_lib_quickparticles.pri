QT.quickparticles.VERSION = 6.12.0
QT.quickparticles.name = QtQuickParticles
QT.quickparticles.module = Qt6QuickParticles
QT.quickparticles.libs = $$QT_MODULE_LIB_BASE
QT.quickparticles.ldflags = 
QT.quickparticles.includes = $$QT_MODULE_INCLUDE_BASE $$QT_MODULE_INCLUDE_BASE/QtQuickParticles
QT.quickparticles.frameworks = 
QT.quickparticles.bins = $$QT_MODULE_BIN_BASE
QT.quickparticles.depends =  quick
QT.quickparticles.run_depends = core gui qml core_private gui_private qml_private
QT.quickparticles.uses = 
QT.quickparticles.module_config = v2
QT.quickparticles.DEFINES = QT_QUICKPARTICLES_LIB
QT.quickparticles.enabled_features = 
QT.quickparticles.disabled_features = 
QT_CONFIG += 
QT_MODULES += quickparticles

