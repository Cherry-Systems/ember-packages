QT.quickcontrols2native.VERSION = 6.12.0
QT.quickcontrols2native.name = QtQuickControls2Native
QT.quickcontrols2native.module = Qt6QuickControls2Native
QT.quickcontrols2native.libs = $$QT_MODULE_LIB_BASE
QT.quickcontrols2native.ldflags = 
QT.quickcontrols2native.includes = $$QT_MODULE_INCLUDE_BASE $$QT_MODULE_INCLUDE_BASE/QtQuickControls2Native
QT.quickcontrols2native.frameworks = 
QT.quickcontrols2native.bins = $$QT_MODULE_BIN_BASE
QT.quickcontrols2native.depends =  
QT.quickcontrols2native.run_depends = quickcontrols2fusion qml
QT.quickcontrols2native.uses = 
QT.quickcontrols2native.module_config = v2
QT.quickcontrols2native.DEFINES = QT_QUICKCONTROLS2NATIVE_LIB
QT.quickcontrols2native.enabled_features = 
QT.quickcontrols2native.disabled_features = 
QT_CONFIG += 
QT_MODULES += quickcontrols2native

