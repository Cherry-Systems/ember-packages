QT.quickshapesdesignhelpers.VERSION = 6.12.0
QT.quickshapesdesignhelpers.name = QtQuickShapesDesignHelpers
QT.quickshapesdesignhelpers.module = Qt6QuickShapesDesignHelpers
QT.quickshapesdesignhelpers.libs = $$QT_MODULE_LIB_BASE
QT.quickshapesdesignhelpers.ldflags = 
QT.quickshapesdesignhelpers.includes = $$QT_MODULE_INCLUDE_BASE $$QT_MODULE_INCLUDE_BASE/QtQuickShapesDesignHelpers
QT.quickshapesdesignhelpers.frameworks = 
QT.quickshapesdesignhelpers.bins = $$QT_MODULE_BIN_BASE
QT.quickshapesdesignhelpers.depends =  core qml
QT.quickshapesdesignhelpers.run_depends = gui quick quickshapes gui_private quick_private quickshapes_private
QT.quickshapesdesignhelpers.uses = 
QT.quickshapesdesignhelpers.module_config = v2
QT.quickshapesdesignhelpers.DEFINES = QT_QUICKSHAPESDESIGNHELPERS_LIB
QT.quickshapesdesignhelpers.enabled_features = 
QT.quickshapesdesignhelpers.disabled_features = 
QT_CONFIG += 
QT_MODULES += quickshapesdesignhelpers

