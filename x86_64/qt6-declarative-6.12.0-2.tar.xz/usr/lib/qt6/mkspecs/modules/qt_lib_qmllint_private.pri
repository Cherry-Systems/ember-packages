QT.qmllint_private.VERSION = 6.12.0
QT.qmllint_private.name = QtQmlLint
QT.qmllint_private.module = Qt6QmlLint
QT.qmllint_private.libs = $$QT_MODULE_LIB_BASE
QT.qmllint_private.ldflags = 
QT.qmllint_private.includes = $$QT_MODULE_INCLUDE_BASE $$QT_MODULE_INCLUDE_BASE/QtQmlLint $$QT_MODULE_INCLUDE_BASE/QtQmlLint/6.12.0 $$QT_MODULE_INCLUDE_BASE/QtQmlLint/6.12.0/QtQmlLint
QT.qmllint_private.frameworks = 
QT.qmllint_private.bins = $$QT_MODULE_BIN_BASE
QT.qmllint_private.plugin_types = qmllint
QT.qmllint_private.depends =  core_private qmldom_private qmlcompiler_private qmltoolingsettings_private
QT.qmllint_private.uses = 
QT.qmllint_private.module_config = v2 internal_module staticlib
QT.qmllint_private.DEFINES = QT_QMLLINT_LIB
QT.qmllint_private.enabled_features = 
QT.qmllint_private.disabled_features = 
QT_CONFIG += 
QT_MODULES += qmllint_private

