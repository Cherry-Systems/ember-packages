#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "KF6::UnitConversion" for configuration "Release"
set_property(TARGET KF6::UnitConversion APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(KF6::UnitConversion PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "Qt6::Network;KF6::I18n"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libKF6UnitConversion.so.6.30.0"
  IMPORTED_SONAME_RELEASE "libKF6UnitConversion.so.6"
  )

list(APPEND _cmake_import_check_targets KF6::UnitConversion )
list(APPEND _cmake_import_check_files_for_KF6::UnitConversion "${_IMPORT_PREFIX}/lib/libKF6UnitConversion.so.6.30.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
