# Ember ships no offline KDE handbooks, so these functions accept their arguments and do nothing.
set(KF6DocTools_FOUND TRUE)

function(kdoctools_create_handbook docbook)
endfunction()

function(kdoctools_create_manpage docbook section)
endfunction()

function(kdoctools_install podir)
endfunction()
