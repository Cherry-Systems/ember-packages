// Copyright (C) 2016 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR LGPL-3.0-only OR GPL-2.0-only OR GPL-3.0-only
// Qt-Security score:significant reason:default

#ifndef QTCONCURRENT_GLOBAL_H
#define QTCONCURRENT_GLOBAL_H

#include <QtCore/qglobal.h>
#include <QtConcurrent/qtconcurrentexports.h>

#endif // include guard
