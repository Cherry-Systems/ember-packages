/*
    SPDX-FileCopyrightText: 2020 Nicolas Fella <nicolas.fella@gmx.de>
    SPDX-License-Identifier: LGPL-2.1-or-later
*/
pragma ComponentBehavior: Bound

import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

import org.kde.purpose
import org.kde.kirigami as Kirigami
import org.kde.ki18n

/*!
  \qmltype JobView
  \inqmlmodule org.kde.purpose

  JobView
*/
Item {

    /*!
      \qmlproperty AlternativesModel JobView::model
     */
    property alias model: jobController.model

    /*!
      \qmlproperty int JobView::index
     */
    property alias index: jobController.index

    /*!
      \qmlproperty enumeration JobView::state
     */
    readonly property alias jobState: jobController.state

    /*!
      \qmlproperty enumeration JobView::state
      \deprecated[6.27]
      Use jobState
     */
    @Deprecated { reason: "Use jobState instead" }
    readonly property alias state: jobController.state // qmllint disable property-override

    /*!
      \qmlproperty Job JobView::job
     */
    readonly property alias job: jobController.job

    implicitHeight: mainLoader.implicitHeight

    function start() {
        jobController.configure()
    }

    KI18nContext {
        id: _tr
        translationDomain: "libpurpose6_quick"
    }

    PurposeJobController {
        id: jobController
    }

    Loader {
        id: mainLoader
        anchors.fill: parent

        sourceComponent: {
            switch (jobController.state) {
            case PurposeJobController.Configuring:
                return configuring;
            case PurposeJobController.Running:
                return running;
            default:
                return null;
            }
        }
    }

    Component {
        id: running

        Item {
            BusyIndicator {
                running: true
                anchors.centerIn: parent
            }
        }
    }

    Component {
        id: configuring

        ColumnLayout {
            Loader {
                id: configLoader

                Layout.leftMargin: Kirigami.Units.largeSpacing
                Layout.rightMargin: Kirigami.Units.largeSpacing
                Layout.topMargin: Kirigami.Units.largeSpacing

                Layout.fillHeight: true
                Layout.fillWidth: true

                Component.onCompleted: setSource(jobController.configuration.configSourceCode, jobController.configuration.data)

                onItemChanged: {
                    var initialData = jobController.configuration.data;
                    for (const i in jobController.configuration.neededArguments) {
                        const arg = jobController.configuration.neededArguments[i];
                        if (arg in configLoader.item) {
                            item[arg + "Changed"].connect(dataHasChanged);
                            initialData[arg] = item[arg];
                        } else {
                            console.warn("property not found", arg);
                        }
                    }
                    jobController.configuration.data = initialData;
                }

                function dataHasChanged() {
                    var jobData = jobController.configuration.data;
                    for (const i in jobController.configuration.neededArguments) {
                        const arg = jobController.configuration.neededArguments[i];
                        if (arg in configLoader.item) {
                            jobData[arg] = configLoader.item[arg];
                        } else
                            console.warn("property not found", arg);
                    }
                    jobController.configuration.data = jobData;
                }
            }

            Label {
                textFormat: Text.PlainText
                Layout.fillWidth: true
                Layout.fillHeight: true
                horizontalAlignment: Text.AlignHCenter
                verticalAlignment: Text.AlignVCenter
                visible: configLoader.status === Loader.Error
                wrapMode: Text.WordWrap
                text: configLoader.status === Loader.Error
                    ? _tr.i18n("Failed to load the configuration page for this action:\n\n%1", configLoader.sourceComponent.errorString())
                    : ""
            }

            // Not using a DialogButtonBox because it doesn't let us customize
            // the buttons and conditionally disable any of them, which we want
            RowLayout {
                Layout.leftMargin: Kirigami.Units.largeSpacing
                Layout.rightMargin: Kirigami.Units.largeSpacing
                Layout.bottomMargin: Kirigami.Units.largeSpacing
                Layout.alignment: Qt.AlignRight

                Button {
                    text: _tr.i18n("Send")
                    icon.name: "document-send"
                    enabled: jobController.configuration
                        && jobController.configuration.isReady
                    onClicked: jobController.startJob()
                }

                Button {
                    text: _tr.i18n("Cancel")
                    icon.name: "dialog-cancel"
                    onClicked: jobController.cancel()
                }
            }
        }
    }
}
