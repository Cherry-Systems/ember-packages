#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "KF6::Completion" for configuration "Release"
set_property(TARGET KF6::Completion APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(KF6::Completion PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "KF6::ConfigCore;KF6::ConfigGui;KF6::WidgetsAddons;KF6::Codecs"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libKF6Completion.so.6.30.0"
  IMPORTED_SONAME_RELEASE "libKF6Completion.so.6"
  )

list(APPEND _cmake_import_check_targets KF6::Completion )
list(APPEND _cmake_import_check_files_for_KF6::Completion "${_IMPORT_PREFIX}/lib/libKF6Completion.so.6.30.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
