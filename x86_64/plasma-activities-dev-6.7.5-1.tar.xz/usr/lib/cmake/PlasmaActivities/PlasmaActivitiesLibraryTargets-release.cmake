#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Plasma::Activities" for configuration "Release"
set_property(TARGET Plasma::Activities APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Plasma::Activities PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "Qt6::DBus"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libPlasmaActivities.so.6.7.5"
  IMPORTED_SONAME_RELEASE "libPlasmaActivities.so.7"
  )

list(APPEND _cmake_import_check_targets Plasma::Activities )
list(APPEND _cmake_import_check_files_for_Plasma::Activities "${_IMPORT_PREFIX}/lib/libPlasmaActivities.so.6.7.5" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
