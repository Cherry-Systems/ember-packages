
#ifndef PROCESSCORE_EXPORT_H
#define PROCESSCORE_EXPORT_H

#ifdef PROCESSCORE_STATIC_DEFINE
#  define PROCESSCORE_EXPORT
#  define PROCESSCORE_NO_EXPORT
#else
#  ifndef PROCESSCORE_EXPORT
#    ifdef processcore_EXPORTS
        /* We are building this library */
#      define PROCESSCORE_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define PROCESSCORE_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef PROCESSCORE_NO_EXPORT
#    define PROCESSCORE_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef PROCESSCORE_DEPRECATED
#  define PROCESSCORE_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef PROCESSCORE_DEPRECATED_EXPORT
#  define PROCESSCORE_DEPRECATED_EXPORT PROCESSCORE_EXPORT PROCESSCORE_DEPRECATED
#endif

#ifndef PROCESSCORE_DEPRECATED_NO_EXPORT
#  define PROCESSCORE_DEPRECATED_NO_EXPORT PROCESSCORE_NO_EXPORT PROCESSCORE_DEPRECATED
#endif

/* NOLINTNEXTLINE(readability-avoid-unconditional-preprocessor-if) */
#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef PROCESSCORE_NO_DEPRECATED
#    define PROCESSCORE_NO_DEPRECATED
#  endif
#endif

#endif /* PROCESSCORE_EXPORT_H */
