QT.multimediaquick.VERSION = 6.12.0
QT.multimediaquick.name = QtMultimediaQuick
QT.multimediaquick.module = Qt6MultimediaQuick
QT.multimediaquick.libs = $$QT_MODULE_LIB_BASE
QT.multimediaquick.ldflags = 
QT.multimediaquick.includes = $$QT_MODULE_INCLUDE_BASE $$QT_MODULE_INCLUDE_BASE/QtMultimediaQuick
QT.multimediaquick.frameworks = 
QT.multimediaquick.bins = $$QT_MODULE_BIN_BASE
QT.multimediaquick.depends =  core multimedia quick
QT.multimediaquick.run_depends = qml
QT.multimediaquick.uses = 
QT.multimediaquick.module_config = v2
QT.multimediaquick.DEFINES = QT_MULTIMEDIAQUICK_LIB
QT.multimediaquick.enabled_features = 
QT.multimediaquick.disabled_features = 
QT_CONFIG += 
QT_MODULES += multimediaquick

