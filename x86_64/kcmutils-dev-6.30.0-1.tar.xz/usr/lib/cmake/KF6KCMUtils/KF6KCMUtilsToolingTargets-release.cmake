#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "KF6::kcmdesktopfilegenerator" for configuration "Release"
set_property(TARGET KF6::kcmdesktopfilegenerator APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(KF6::kcmdesktopfilegenerator PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libexec/kf6/kcmdesktopfilegenerator"
  )

list(APPEND _cmake_import_check_targets KF6::kcmdesktopfilegenerator )
list(APPEND _cmake_import_check_files_for_KF6::kcmdesktopfilegenerator "${_IMPORT_PREFIX}/lib/libexec/kf6/kcmdesktopfilegenerator" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
