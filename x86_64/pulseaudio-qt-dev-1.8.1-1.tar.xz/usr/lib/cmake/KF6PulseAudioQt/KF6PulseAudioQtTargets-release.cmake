#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "KF6::PulseAudioQt" for configuration "Release"
set_property(TARGET KF6::PulseAudioQt APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(KF6::PulseAudioQt PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "Qt6::Gui;Qt6::DBus"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libKF6PulseAudioQt.so.1.8.1"
  IMPORTED_SONAME_RELEASE "libKF6PulseAudioQt.so.5"
  )

list(APPEND _cmake_import_check_targets KF6::PulseAudioQt )
list(APPEND _cmake_import_check_files_for_KF6::PulseAudioQt "${_IMPORT_PREFIX}/lib/libKF6PulseAudioQt.so.1.8.1" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
