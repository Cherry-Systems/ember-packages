!host_build {
    QMAKE_CFLAGS    += --sysroot=$$[QT_SYSROOT]
    QMAKE_CXXFLAGS  += --sysroot=$$[QT_SYSROOT]
    QMAKE_LFLAGS    += --sysroot=$$[QT_SYSROOT]
}
QT_ARCH = x86_64
QT_BUILDABI = 
QT_LIBCPP_ABI_TAG = 
QT.global.enabled_features = version_tagging shared pkg-config rpath signaling_nan zstd thread future concurrent dbus openssl-linked opensslv30 test_gui test_squish test_auto shared intelcet glibc_fortify_source trivial_auto_var_init_pattern stack_protector stack_clash_protection libstdcpp_assertions relro_now_linker shared rpath reduce_exports openssl
QT.global.disabled_features = static cross_compile debug_and_release separate_debug_info appstore-compliant simulator_and_device force_asserts framework c++20 c++2a c++2b c++2c reduce_relocations wasm-simd128 wasm-exceptions wasm-jspi opensslv11 static_compiler_runtime test_baseline
QT.global.disabled_features += release build_all
QT_CONFIG += shared rpath reduce_exports openssl release
CONFIG += release  shared plugin_manifest intelcet glibc_fortify_source trivial_auto_var_init_pattern stack_protector stack_clash_protection libstdcpp_assertions relro_now_linker
QT_VERSION = 6.12.0
QT_MAJOR_VERSION = 6
QT_MINOR_VERSION = 12
QT_PATCH_VERSION = 0

QT_GCC_MAJOR_VERSION = 16
QT_GCC_MINOR_VERSION = 2
QT_GCC_PATCH_VERSION = 0
