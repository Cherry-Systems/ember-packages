QT.core.VERSION = 6.12.0
QT.core.name = QtCore
QT.core.module = Qt6Core
QT.core.libs = $$QT_MODULE_LIB_BASE
QT.core.ldflags = 
QT.core.includes = $$QT_MODULE_INCLUDE_BASE $$QT_MODULE_INCLUDE_BASE/QtCore
QT.core.frameworks = 
QT.core.bins = $$QT_MODULE_BIN_BASE
QT.core.depends =  
QT.core.uses = libatomic
QT.core.module_config = v2
QT.core.CONFIG = moc resources
QT.core.DEFINES = QT_CORE_LIB
QT.core.enabled_features = clock-monotonic cxx11_future cxx17_filesystem glib inotify std-atomic64 mimetype sharedmemory shortcut systemsemaphore xmlstream xmlstreamreader xmlstreamwriter textdate datestring process processenvironment temporaryfile library settings filesystemwatcher filesystemiterator itemmodel rangemodel proxymodel sortfilterproxymodel identityproxymodel transposeproxymodel concatenatetablesproxymodel stringlistmodel translation easingcurve animation gestures jalalicalendar islamiccivilcalendar timezone commandlineparser cborstreamreader cborstreamwriter permissions threadsafe-cloexec version_tagging shared pkg-config rpath signaling_nan zstd thread future concurrent dbus openssl-linked opensslv30 test_gui test_squish test_auto shared intelcet glibc_fortify_source trivial_auto_var_init_pattern stack_protector stack_clash_protection libstdcpp_assertions relro_now_linker shared rpath reduce_exports openssl
QT.core.disabled_features = jemalloc cpp-winrt timezone_tzdb randomgenerator_disable_fallback static cross_compile debug_and_release separate_debug_info appstore-compliant simulator_and_device force_asserts framework c++20 c++2a c++2b c++2c reduce_relocations wasm-simd128 wasm-exceptions wasm-jspi opensslv11 static_compiler_runtime test_baseline
QT_CONFIG += clock-monotonic cxx11_future cxx17_filesystem glib inotify std-atomic64 mimetype sharedmemory shortcut systemsemaphore xmlstream xmlstreamreader xmlstreamwriter textdate datestring process processenvironment temporaryfile library settings filesystemwatcher filesystemiterator itemmodel rangemodel proxymodel sortfilterproxymodel identityproxymodel transposeproxymodel concatenatetablesproxymodel stringlistmodel translation easingcurve animation gestures jalalicalendar islamiccivilcalendar timezone commandlineparser cborstreamreader cborstreamwriter permissions threadsafe-cloexec version_tagging shared pkg-config rpath signaling_nan zstd thread future concurrent dbus openssl-linked opensslv30 test_gui test_squish test_auto shared intelcet glibc_fortify_source trivial_auto_var_init_pattern stack_protector stack_clash_protection libstdcpp_assertions relro_now_linker shared rpath reduce_exports openssl
QT_MODULES += core

