// Copyright (C) 2025 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR LGPL-3.0-only OR GPL-2.0-only OR GPL-3.0-only

#ifndef QPIPEWIRE_AUDIOCONTEXTMANAGER_P_H
#define QPIPEWIRE_AUDIOCONTEXTMANAGER_P_H

//
//  W A R N I N G
//  -------------
//
// This file is not part of the Qt API. It exists purely as an
// implementation detail. This header file may change from version to
// version without notice, or even be removed.
//
// We mean it.
//

#include <QtMultimedia/private/qpipewire_audiodevicemonitor_p.h>
#include <QtMultimedia/private/qpipewire_registry_support_p.h>
#include <QtMultimedia/private/qpipewire_support_p.h>
#include <QtMultimedia/private/qpipewire_instance_p.h>
#include <QtCore/qglobal.h>

#include <pipewire/pipewire.h>

QT_BEGIN_NAMESPACE

namespace QtPipeWire {

struct QPipewireAudioStream;

class QAudioContextManager
{
public:
    QAudioContextManager();
    ~QAudioContextManager();

    static bool minimumRequirementMet();

    static QAudioContextManager *instance();
    bool isConnected() const;

    template <typename Closure>
    static auto withEventLoopLock(Closure &&c)
    {
        QAudioContextManager *self = instance();
        return self->m_pwInstance->runWithEventLoopLock(std::forward<Closure>(c));
    }

    static QAudioDeviceMonitor &deviceMonitor();

    static bool isInPwThreadLoop();
    static pw_loop *getEventLoop();

    PwNodeHandle bindNode(ObjectId);
    PwMetadataHandle bindMetadata(ObjectId);

    void syncRegistry();

    void registerStreamReference(std::shared_ptr<QPipewireAudioStream>);
    void unregisterStreamReference(const std::shared_ptr<QPipewireAudioStream> &);

    const PwCoreConnectionHandle &coreConnection() const;

private:
    const std::shared_ptr<QPipeWireInstance> m_pwInstance;

    // pw_core connection
    PwCoreConnectionHandle m_coreConnection;

    // device monitor
    PwRegistryHandle m_registry;
    spa_hook m_registryListener{};
    std::unique_ptr<QAudioDeviceMonitor> m_deviceMonitor;

    void startDeviceMonitor();
    void stopDeviceMonitor();
    static void objectAddedCb(void *data, uint32_t id, uint32_t permissions, const char *type,
                              uint32_t version, const struct spa_dict *props);
    static void objectRemovedCb(void *data, uint32_t id);
    void objectAdded(ObjectId id, uint32_t permissions, PipewireRegistryType, uint32_t version,
                     const spa_dict &props);
    void objectRemoved(ObjectId id);

    // default metadata object
    void startListenDefaultMetadataObject(ObjectId, uint32_t version);
    void stopListenDefaultMetadataObject();
    struct MetadataRecord
    {
        const char *key;
        const char *type;
        const char *value;
    };

    int handleDefaultMetadataObjectEvent(ObjectId subject, const MetadataRecord &);

    PwMetadataHandle m_defaultMetadataObject;
    spa_hook m_defaultMetadataObjectListener{};

    QMutex m_activeStreamMutex;
    std::set<std::shared_ptr<QPipewireAudioStream>> m_activeStreams;
    void stopActiveStreams();
};

} // namespace QtPipeWire

QT_END_NAMESPACE

#endif // QPIPEWIRE_AUDIOCONTEXTMANAGER_P_H
