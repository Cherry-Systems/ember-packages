// Copyright (C) 2026 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR LGPL-3.0-only OR GPL-2.0-only OR GPL-3.0-only

#ifndef QWINDOWCAPTURE_P_H
#define QWINDOWCAPTURE_P_H

#include <QtCore/private/qobject_p.h>

#include <QtMultimedia/qwindowcapture.h>

#include <memory>

//
//  W A R N I N G
//  -------------
//
// This file is not part of the Qt API.  It exists purely as an
// implementation detail.  This header file may change from version to
// version without notice, or even be removed.
//
// We mean it.
//

QT_BEGIN_NAMESPACE

class QMediaCaptureSession;
class QPlatformSurfaceCapture;

class Q_MULTIMEDIA_EXPORT QWindowCapturePrivate : public QObjectPrivate
{
public:
    [[nodiscard]] static QWindowCapturePrivate *get(QWindowCapture &capture)
    {
        return capture.d_func();
    }

    QMediaCaptureSession *captureSession = nullptr;
    std::unique_ptr<QPlatformSurfaceCapture> platformWindowCapture;

    // Only applied when next stream starts.
    void setIgnoreCursor(bool);
    // Only applied when next stream starts.
    void setIgnoreDropShadow(bool);
};

QT_END_NAMESPACE

#endif // QWINDOWCAPTURE_P_H
