#ifndef QT_FEATURES_Multimedia_src_multimedia_qtmultimedia_config_p_h_H
#define QT_FEATURES_Multimedia_src_multimedia_qtmultimedia_config_p_h_H

#define QT_FEATURE_pipewire 1

#define QT_FEATURE_pipewire_screencapture 1

#define QT_FEATURE_pipewire_symbolloader 1

#define QT_FEATURE_alsa -1

#define QT_FEATURE_avfoundation -1

#define QT_FEATURE_coreaudio -1

#define QT_FEATURE_videotoolbox -1

#define QT_FEATURE_gstreamer -1

#define QT_FEATURE_gstreamer_photography -1

#define QT_FEATURE_gstreamer_gl -1

#define QT_FEATURE_gstreamer_gl_wayland -1

#define QT_FEATURE_gstreamer_gl_egl -1

#define QT_FEATURE_gstreamer_gl_x11 -1

#define QT_FEATURE_gpu_vivante -1

#define QT_FEATURE_gstreamer_qt_api -1

#define QT_FEATURE_linux_v4l 1

#define QT_FEATURE_linux_dmabuf 1

#define QT_FEATURE_vaapi 1

#define QT_FEATURE_mmrenderer -1

#define QT_FEATURE_qnx_io_audio -1

#define QT_FEATURE_qnx_io_snd -1

#define QT_FEATURE_native_android_backend -1

#define QT_FEATURE_native_windows_backend -1

#define QT_FEATURE_native_darwin_backend -1

#define QT_FEATURE_native_ohos_backend -1

#define QT_FEATURE_pulseaudio 1

#define QT_FEATURE_aaudio -1

#define QT_FEATURE_ohaudio -1

#define QT_FEATURE_wasm -1

#define QT_FEATURE_wasapi -1

#define QT_FEATURE_multimedia_quick 1

#define QT_FEATURE_spatialaudio 1

#define QT_FEATURE_spatialaudio_quick3d -1

#define QT_FEATURE_ffmpeg 1

#define QT_FEATURE_ffmpeg_stubs -1


#endif // QT_FEATURES_Multimedia_src_multimedia_qtmultimedia_config_p_h_H
