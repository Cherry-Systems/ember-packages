// Copyright (C) 2016 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR LGPL-3.0-only OR GPL-2.0-only OR GPL-3.0-only


#ifndef QAUDIOINPUT_H
#define QAUDIOINPUT_H

#include <QtMultimedia/qaudiodevice.h>
#include <QtMultimedia/qaudioformat.h>
#include <QtMultimedia/qtaudio.h>
#include <QtMultimedia/qtmultimediaglobal.h>
#include <QtCore/qiodevice.h>


QT_BEGIN_NAMESPACE

class QPlatformAudioSource;

class Q_MULTIMEDIA_EXPORT QAudioSource : public QObject
{
    Q_OBJECT

public:
    explicit QAudioSource(const QAudioFormat &format = QAudioFormat(), QObject *parent = nullptr);
    explicit QAudioSource(const QAudioDevice &audioDeviceInfo, const QAudioFormat &format = QAudioFormat(), QObject *parent = nullptr);
    ~QAudioSource() override;

    bool isNull() const { return !d; }

    QAudioFormat format() const;

    void start(QIODevice *device);
    QIODevice* start();

    template <typename Callback, QtAudio::if_audio_source_callback<Callback> = true>
    void start(Callback &&cb)
    {
        Q_ASSERT(QtAudioPrivate::isNonnullFunction(cb));

        if constexpr (!std::is_copy_constructible_v<Callback>) {
            // poor man's move-only function
            using CallbackType = typename QtAudioPrivate::GetSampleType<Callback>::type;
            auto callback = std::make_shared<std::decay_t<Callback>>(std::forward<Callback>(cb));
            start([callback = std::move(callback)](QSpan<const CallbackType> arg) {
                (*callback)(arg);
            });
        } else {
            startABIImpl(QtAudioPrivate::AudioSourceCallback(std::forward<Callback>(cb)));
        }
    }

    void stop();
    void reset();
    void suspend();
    void resume();

    void setBufferSize(qsizetype bytes);
    qsizetype bufferSize() const;

    void setBufferFrameCount(qsizetype frames);
    qsizetype bufferFrameCount() const;

    void setNativePeriodFrameCount(qsizetype frameCount);
    qsizetype nativePeriodFrameCount() const;

    qsizetype bytesAvailable() const;
    qsizetype framesAvailable() const;

    void setVolume(qreal volume);
    qreal volume() const;

    qint64 processedUSecs() const;
    qint64 elapsedUSecs() const;

    QtAudio::Error error() const;
    QtAudio::State state() const;

Q_SIGNALS:
#if defined(Q_QDOC)
    void stateChanged(QtAudio::State state);
#else
    // use QAudio here to keep string-based connections working
    void stateChanged(QAudio::State state);
#endif

private:
    template <typename T>
    void startImpl(T &&);

    void startABIImpl(QtAudioPrivate::AudioSourceCallback &&);

    Q_DISABLE_COPY(QAudioSource)
    friend class QPlatformAudioSource;

    QPlatformAudioSource *d;
};

QT_END_NAMESPACE

#endif // QAUDIOINPUT_H
