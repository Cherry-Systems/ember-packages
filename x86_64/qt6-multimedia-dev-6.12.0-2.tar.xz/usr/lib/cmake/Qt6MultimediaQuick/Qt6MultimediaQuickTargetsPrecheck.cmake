
_qt_internal_should_include_targets(
    TARGETS MultimediaQuick
    NAMESPACE Qt6::
    OUT_VAR_SHOULD_SKIP __qt_MultimediaQuick_skip_include_targets_file
)
