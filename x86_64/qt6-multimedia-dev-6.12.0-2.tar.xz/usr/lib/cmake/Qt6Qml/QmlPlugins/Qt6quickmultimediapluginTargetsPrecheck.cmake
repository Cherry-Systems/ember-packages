
_qt_internal_should_include_targets(
    TARGETS quickmultimediaplugin
    NAMESPACE Qt6::
    PROJECT_NAMES QtMultimedia
    SKIP_IF_PROJECT_NAME_NOT_IN_QT_REPO_DEPENDENCIES
    OUT_VAR_SHOULD_SKIP __qt_quickmultimediaplugin_skip_include_targets_file
    
)
