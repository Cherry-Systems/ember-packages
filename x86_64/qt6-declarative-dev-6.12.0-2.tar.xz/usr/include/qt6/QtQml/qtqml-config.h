#ifndef QT_FEATURES_Qml_src_qml_qtqml_config_h_H
#define QT_FEATURES_Qml_src_qml_qtqml_config_h_H

#define QT_FEATURE_qml_network 1

#define QT_FEATURE_qml_ssl 1

#define QT_FEATURE_qml_debug -1

#define QT_FEATURE_qml_labs 1

#define QT_FEATURE_qml_designsupport 1


#endif // QT_FEATURES_Qml_src_qml_qtqml_config_h_H
