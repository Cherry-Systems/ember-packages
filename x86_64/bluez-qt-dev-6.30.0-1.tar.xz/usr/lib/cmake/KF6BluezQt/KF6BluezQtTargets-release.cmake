#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "KF6::BluezQt" for configuration "Release"
set_property(TARGET KF6::BluezQt APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(KF6::BluezQt PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "Qt6::Network"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libKF6BluezQt.so.6.30.0"
  IMPORTED_SONAME_RELEASE "libKF6BluezQt.so.6"
  )

list(APPEND _cmake_import_check_targets KF6::BluezQt )
list(APPEND _cmake_import_check_files_for_KF6::BluezQt "${_IMPORT_PREFIX}/lib/libKF6BluezQt.so.6.30.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
