#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "KF6::BalooWidgets" for configuration "Release"
set_property(TARGET KF6::BalooWidgets APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(KF6::BalooWidgets PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "KF6::I18n;KF6::FileMetaData;KF6::WidgetsAddons;KF6::Baloo;KF6::ConfigGui;KF6::Service"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libKF6BalooWidgets.so.26.08.1"
  IMPORTED_SONAME_RELEASE "libKF6BalooWidgets.so.6"
  )

list(APPEND _cmake_import_check_targets KF6::BalooWidgets )
list(APPEND _cmake_import_check_files_for_KF6::BalooWidgets "${_IMPORT_PREFIX}/lib/libKF6BalooWidgets.so.26.08.1" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
